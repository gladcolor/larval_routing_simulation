"""Dependency-free coverage lift metrics for internal research evaluation.

This package evaluates supplied scores. It does not fit a prediction model,
verify held-out validation, estimate uncertainty, or measure treatment effects.
"""

from .metrics import (
    ENGINE_VERSION,
    SPECIFICATION,
    LiftResult,
    coverage_at,
    evaluate,
    target_coverage,
)

__version__ = "0.1.0"
__all__ = [
    "ENGINE_VERSION", "SPECIFICATION", "LiftResult", "__version__",
    "evaluate", "coverage_at", "target_coverage",
]
