"""Numerically stable, tie-aware coverage lift without third-party dependencies.

Every row receives equal horizontal weight. For exact score ties, the coverage
curve is the expectation over all within-block permutations, not the displayed
row ordering. Integration is over the full [0, 1] selection domain.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from math import ceil, floor, fsum, isfinite
from numbers import Real
import re
import sys
from typing import Any, Iterable

ENGINE_VERSION = "1.0.0"
SPECIFICATION = "coverage-lift-v1.0"
PACKAGE_VERSION = "0.1.0"
MAX_ROWS = 100_000
_NUMBER = re.compile(r"[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?", re.ASCII)


@dataclass(frozen=True)
class LiftResult:
    """Evaluation result; nested lists/dicts are ordinary Python containers.

    Undefined quantities are ``None``. ``ordering`` contains zero-based input
    indices, while displayed ranks and generated row IDs start at one.
    """

    n: int
    total: float | None
    mean: float
    auc_model: float | None
    auc_ideal: float | None
    denominator: float | None
    model_advantage: float | None
    lift: float | None
    status: str
    warnings: list[str]
    curve: list[dict[str, float | None]]
    direction: str
    zero_count: int
    positive_count: int
    unique_score_count: int
    budget: dict[str, Any]
    tie_blocks: list[dict[str, Any]]
    ordering: list[int]
    ranked_rows: list[dict[str, Any]]
    engine_version: str = ENGINE_VERSION
    specification: str = SPECIFICATION
    package_version: str = PACKAGE_VERSION

    def to_dict(self) -> dict[str, Any]:
        """Return a detached, JSON-compatible snake_case representation."""
        return asdict(self)


def _numeric(value: Any, label: str, row: int) -> float:
    if isinstance(value, str):
        value = value.strip()
        if not value or _NUMBER.fullmatch(value) is None:
            raise ValueError(f"Row {row}: {label} must contain a finite number, not blank or formatted text.")
    elif isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError(f"Row {row}: {label} must contain a finite number.")
    try:
        number = float(value)
    except (ValueError, OverflowError) as error:
        raise ValueError(f"Row {row}: {label} must contain a finite number.") from error
    if not isfinite(number):
        raise ValueError(f"Row {row}: {label} must contain a finite number.")
    return number


def _fraction(value: Any, label: str) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError(f"{label} must be a finite number from 0 to 1 inclusive.")
    try:
        value = float(value)
    except OverflowError as error:
        raise ValueError(f"{label} must be a finite number from 0 to 1 inclusive.") from error
    if not isfinite(value) or not 0 <= value <= 1:
        raise ValueError(f"{label} must be a finite number from 0 to 1 inclusive.")
    return value


def _values(values: Iterable[Any], label: str) -> list[Any]:
    if isinstance(values, (str, bytes)):
        raise ValueError(f"{label} must be an iterable of values, not a string.")
    try:
        return list(values)
    except TypeError as error:
        raise ValueError(f"{label} must be an iterable of values.") from error


def _ranked_coverage(values: list[float], scores: list[float], direction: str) -> dict[str, Any]:
    n = len(values)
    # Python's sort is stable. Equal scores retain input order only for display.
    order = sorted(range(n), key=lambda i: scores[i], reverse=direction == "high")
    total = fsum(values)
    coverage: list[float | None] = [0.0] + [None] * n
    groups: list[dict[str, Any]] = []
    cumulative = correction = 0.0
    start = 0
    while start < n:
        end = start + 1
        while end < n and scores[order[end]] == scores[order[start]]:
            end += 1
        block = fsum(values[order[i]] for i in range(start, end))
        previous = cumulative + correction
        following = cumulative + block
        correction += ((cumulative - following) + block if abs(cumulative) >= abs(block)
                       else (block - following) + cumulative)
        cumulative = following
        final = cumulative + correction
        for j in range(start + 1, end + 1):
            coverage[j] = (previous + block * (j - start) / (end - start)) / total if total > 0 else None
        groups.append({"start": start, "end": end, "count": end - start,
                       "score": scores[order[start]], "total_scaled": block,
                       "previous_coverage": previous / total if total > 0 else None,
                       "final_coverage": final / total if total > 0 else None})
        start = end
    if total > 0:
        coverage[n] = 1.0
    else:
        coverage[0] = None
    return {"order": order, "coverage": coverage, "groups": groups}


def _at(curve: list[dict[str, Any]], fraction: float, key: str = "model") -> float | None:
    n = len(curve) - 1
    position = fraction * n
    left = min(floor(position), n)
    if left == n:
        return curve[n][key]
    a, b = curve[left][key], curve[left + 1][key]
    return None if a is None or b is None else a + (b - a) * (position - left)


def evaluate(
    observed: Iterable[Any],
    scores: Iterable[Any],
    *,
    ids: Iterable[Any] | None = None,
    direction: str = "high",
    budget: float = 0.3,
) -> LiftResult:
    """Evaluate nonnegative outcomes against finite ranking scores.

    ``direction='high'`` selects larger scores first; ``'low'`` reverses that
    convention. ``budget`` is an exact fraction in [0, 1]. Both interpolated
    coverage and a floor whole-site comparator are returned. Values are never
    silently dropped. Numeric strings are accepted; booleans and missing values
    are rejected. Optional IDs must be nonblank and unique after string trimming.

    The normalized full-curve lift is (AUC_model - 0.5)/(AUC_ideal - 0.5).
    Centered rank-weighted sums evaluate those area differences without the
    catastrophic cancellation of directly subtracting nearly equal AUC values.
    """
    yy_input, ss_input = _values(observed, "Observed outcomes"), _values(scores, "Scores")
    n = len(yy_input)
    if n < 2:
        raise ValueError("At least two evaluation rows are required.")
    if n > MAX_ROWS:
        raise ValueError(f"Maximum supported dataset size is {MAX_ROWS:,} rows.")
    if len(ss_input) != n:
        raise ValueError("Observed outcomes and scores must have the same length.")
    if direction not in ("high", "low"):
        raise ValueError("Score direction must be high or low.")
    fraction = _fraction(budget, "Selection fraction")
    yy = [_numeric(value, "observed outcome", i + 1) for i, value in enumerate(yy_input)]
    ss = [_numeric(value, "score", i + 1) for i, value in enumerate(ss_input)]
    for i, value in enumerate(yy):
        if value < 0:
            raise ValueError(f"Row {i + 1}: observed outcomes must be non-negative. Zero is a valid observation.")
    warnings: list[str] = []
    if ids is None:
        labels = [str(i + 1) for i in range(n)]
        warnings.append("No site IDs supplied. Row numbers identify records; duplicate evaluation units cannot be checked.")
    else:
        raw_ids = _values(ids, "IDs")
        if len(raw_ids) != n:
            raise ValueError("IDs and observed outcomes must have the same length.")
        labels = []
        used: set[str] = set()
        for i, value in enumerate(raw_ids):
            label = "" if value is None else str(value).strip()
            if not label:
                raise ValueError(f"Row {i + 1}: the supplied site ID is blank.")
            if label in used:
                raise ValueError(f"Row {i + 1}: duplicate site ID {label!r}. Define one unique evaluation unit per row.")
            used.add(label)
            labels.append(label)
    maximum, minimum = max(yy), min(yy)
    scaled = [y / maximum for y in yy] if maximum > 0 else [0.0] * n
    total_scaled = fsum(scaled)
    total_candidate = maximum * total_scaled
    total = total_candidate if isfinite(total_candidate) else None
    mean = maximum * (total_scaled / n)
    if total is None:
        warnings.append("The observed total exceeds floating-point range. It is unavailable; normalized coverage and lift use scaled values.")
    if any(y > 0 and scaled[i] == 0 for i, y in enumerate(yy)):
        warnings.append("Extreme outcome magnitudes cause negligible positive values to underflow after scaling. Inspect measurement units.")
    model = _ranked_coverage(scaled, ss, direction)
    ideal = _ranked_coverage(scaled, scaled, "high")
    status = "zero_total" if maximum == 0 else "uniform_outcomes" if maximum == minimum else "ok"
    curve = [{"x": i / n, "model": model["coverage"][i], "ideal": ideal["coverage"][i],
              "random": None if status == "zero_total" else i / n} for i in range(n + 1)]
    baseline = minimum / maximum if maximum > 0 else 0.0

    def area_advantage(ranking: dict[str, Any]) -> float | None:
        terms = []
        for group in ranking["groups"]:
            mid_rank = (group["start"] + 1 + group["end"]) / 2
            rank_weight = n + 1 - 2 * mid_rank
            block_delta = fsum(scaled[ranking["order"][i]] - baseline
                               for i in range(group["start"], group["end"]))
            terms.append(rank_weight * block_delta)
        return fsum(terms) / (2 * n * total_scaled) if total_scaled > 0 else None

    model_advantage, denominator = area_advantage(model), area_advantage(ideal)
    auc_model = None if model_advantage is None else 0.5 + model_advantage
    auc_ideal = None if denominator is None else 0.5 + denominator
    lift = model_advantage / denominator if status == "ok" and denominator is not None and denominator > 0 else None
    # Match the browser reference's round-off normalization at exact boundaries.
    # These tolerances never merge scores or outcomes into ties.
    if lift is not None:
        if abs(lift) < 1e-14:
            lift = 0.0
        if abs(lift - 1) < 1e-13:
            lift = 1.0
        if abs(lift + 1) < 1e-13:
            lift = -1.0
    if status == "uniform_outcomes":
        warnings.append("All observed outcomes are equal. The ideal and random areas coincide, so normalized lift is undefined, not zero.")
    if status == "zero_total":
        warnings.append("All observed outcomes are zero. Outcome coverage and normalized lift are undefined.")
    if status == "ok" and denominator is not None and denominator < 1e-10:
        warnings.append("Outcome contrast is extremely small. Normalized lift can be unstable to measurement error; interpret absolute coverage alongside it.")
    k = min(n, floor(fraction * n + 1e-12))
    floor_fraction = k / n
    coverage, floor_coverage = _at(curve, fraction), _at(curve, floor_fraction)
    budget_result = {"fraction": fraction, "site_equivalents": fraction * n, "coverage": coverage,
                     "ideal_coverage": _at(curve, fraction, "ideal"),
                     "multiplier": coverage / fraction if fraction > 0 and coverage is not None else None,
                     "k": k, "floor_fraction": floor_fraction, "floor_coverage": floor_coverage,
                     "floor_multiplier": floor_coverage / floor_fraction if floor_fraction > 0 and floor_coverage is not None else None}
    tie_blocks, ranked_rows = [], []
    for group in model["groups"]:
        selection_probability = max(0.0, min(1.0, (fraction * n - group["start"]) / group["count"]))
        if group["count"] > 1:
            tie_blocks.append({"rank_start": group["start"] + 1, "rank_end": group["end"],
                               "size": group["count"], "score": group["score"],
                               "share": group["total_scaled"] / total_scaled if total_scaled > 0 else None,
                               "cumulative_before": group["previous_coverage"], "cumulative_after": group["final_coverage"],
                               "selection_probability": selection_probability})
        for position in range(group["start"], group["end"]):
            i = model["order"][position]
            ranked_rows.append({"source_index": i, "site_id": labels[i], "observed": yy[i], "score": ss[i],
                                "displayed_position": position + 1, "rank_start": group["start"] + 1,
                                "rank_end": group["end"], "rank_mean": (group["start"] + 1 + group["end"]) / 2,
                                "tie_size": group["count"], "share": scaled[i] / total_scaled if total_scaled > 0 else None,
                                "cumulative_expected": model["coverage"][position + 1],
                                "selection_probability": selection_probability})
    if tie_blocks:
        warnings.append(f"{len(tie_blocks)} tied-score block(s). Coverage uses expected random ordering within each exact-score tie, not the displayed row order.")
    return LiftResult(n=n, total=total, mean=mean, auc_model=auc_model, auc_ideal=auc_ideal,
                      denominator=denominator, model_advantage=model_advantage, lift=lift,
                      status=status, warnings=warnings, curve=curve, direction=direction,
                      zero_count=sum(y == 0 for y in yy), positive_count=sum(y > 0 for y in yy),
                      unique_score_count=len(model["groups"]), budget=budget_result,
                      tie_blocks=tie_blocks, ordering=model["order"], ranked_rows=ranked_rows)


def _check_result(result: LiftResult) -> None:
    if not isinstance(result, LiftResult) or result.n < 2 or len(result.curve) != result.n + 1:
        raise ValueError("Pass a LiftResult produced by evaluate().")


def coverage_at(result: LiftResult, fraction: float, key: str = "model") -> float | None:
    """Interpolate model, ideal, or random coverage at a fraction in [0, 1]."""
    _check_result(result)
    fraction = _fraction(fraction, "Selection fraction")
    if key not in ("model", "ideal", "random"):
        raise ValueError("Coverage key must be model, ideal, or random.")
    return _at(result.curve, fraction, key)


def _inverse(curve: list[dict[str, Any]], target: float, key: str) -> float:
    if target == 0:
        return 0.0
    low, high = 0, len(curve) - 1
    while low < high:
        middle = (low + high) // 2
        if curve[middle][key] >= target:
            high = middle
        else:
            low = middle + 1
    right = curve[low]
    if right[key] is None or right[key] < target:
        raise ValueError("The supplied curve does not reach the target coverage.")
    if low == 0:
        return right["x"]
    left = curve[low - 1]
    rise = right[key] - left[key]
    if rise <= 0:
        return left["x"]
    return max(0.0, min(1.0, left["x"] + (right["x"] - left["x"]) * (target - left[key]) / rise))


def target_coverage(result: LiftResult, target: float) -> dict[str, Any]:
    """Return the first interpolated crossing and whole-site ceiling for a target.

    This is retrospective coverage on evaluated rows, not a prospective forecast.
    Within a score tie, even whole-site coverage remains an expectation.
    """
    _check_result(result)
    target = _fraction(target, "Target coverage")
    if result.status == "zero_total":
        return {"status": "undefined_zero_total", "target": target, "fraction": None,
                "site_equivalents": None, "whole_sites": None, "whole_fraction": None,
                "whole_coverage": None, "random_fraction": None, "ideal_fraction": None}
    fraction = _inverse(result.curve, target, "model")
    ideal_fraction = _inverse(result.curve, target, "ideal")
    equivalents = fraction * result.n
    rounded = floor(equivalents + 0.5)
    tolerance = 8 * sys.float_info.epsilon * max(1.0, abs(equivalents))
    k = rounded if rounded > 0 and abs(equivalents - rounded) <= tolerance else ceil(equivalents)
    k = max(0, min(result.n, k))
    coverage = _at(result.curve, k / result.n)
    value_tolerance = 16 * sys.float_info.epsilon * max(float.fromhex("0x0.0000000000001p-1022"), abs(target), abs(coverage))
    if k < result.n and coverage + value_tolerance < target:
        k += 1
        coverage = _at(result.curve, k / result.n)
    return {"status": result.status, "target": target, "fraction": fraction,
            "site_equivalents": equivalents, "whole_sites": k, "whole_fraction": k / result.n,
            "whole_coverage": coverage, "random_fraction": target, "ideal_fraction": ideal_fraction}
