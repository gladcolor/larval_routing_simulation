"""Local CSV-to-JSON command line interface. No networking or model fitting."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import sys
from typing import Sequence

from . import __version__, evaluate


def _read_csv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.reader(handle, strict=True)
        try:
            header = [value.strip() for value in next(reader)]
        except StopIteration as error:
            raise ValueError("CSV must contain a header and at least two data rows.") from error
        if not header or any(not value for value in header):
            raise ValueError("CSV column headers cannot be blank.")
        if len(set(header)) != len(header):
            raise ValueError("CSV column headers must be unique.")
        rows = []
        for fields in reader:
            if not fields:  # Empty physical lines are not evaluation records.
                continue
            if len(fields) != len(header):
                raise ValueError(f"CSV line {reader.line_num}: expected {len(header)} fields but found {len(fields)}.")
            rows.append(dict(zip(header, fields)))
        return header, rows


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Evaluate equal-site coverage lift from a local CSV. No data are uploaded.")
    parser.add_argument("input", type=Path, help="UTF-8 CSV with a header and one evaluation unit per row")
    parser.add_argument("--outcome", default="observed", help="Nonnegative observed outcome column (default: observed)")
    parser.add_argument("--score", default="score", help="Finite prediction score column (default: score)")
    parser.add_argument("--id", dest="id_column", help="Unique evaluation-unit ID column; otherwise row IDs are generated")
    parser.add_argument("--direction", choices=("high", "low"), default="high")
    parser.add_argument("--budget", type=float, default=0.3, help="Exact selection fraction from 0 to 1 (default: 0.3)")
    parser.add_argument("--output", type=Path, help="JSON report path; default writes JSON to stdout")
    parser.add_argument("--curve-output", type=Path, help="Optional CSV of all model, ideal, and random curve points")
    parser.add_argument("--version", action="version", version=f"entomology-lift {__version__}")
    args = parser.parse_args(argv)
    try:
        input_path = args.input.resolve()
        output_paths = [p.resolve() for p in (args.output, args.curve_output) if p is not None]
        if input_path in output_paths:
            raise ValueError("An output path cannot replace the input CSV.")
        if len(set(output_paths)) != len(output_paths):
            raise ValueError("JSON and curve CSV outputs must use different paths.")
        header, rows = _read_csv(args.input)
        for name in (args.outcome, args.score, args.id_column):
            if name is not None and name not in header:
                raise ValueError(f"Mapped column {name!r} is not in the CSV header.")
        if args.outcome == args.score:
            raise ValueError("Observed outcome and prediction score must use different columns; use the ideal reference for outcome-based ordering.")
        result = evaluate([row[args.outcome] for row in rows], [row[args.score] for row in rows],
                          ids=None if args.id_column is None else [row[args.id_column] for row in rows],
                          direction=args.direction, budget=args.budget)
        report = result.to_dict()
        report["mapping"] = {"observed": args.outcome, "score": args.score, "id": args.id_column}
        report["source"] = {"filename": args.input.name, "format": "CSV", "provenance": "not_verified"}
        report["limitations"] = ["This calculation does not verify held-out prediction independence or estimate uncertainty.",
                                  "Coverage is not treatment effectiveness, cost savings, adult emergence reduction, or malaria reduction."]
        payload = json.dumps(report, ensure_ascii=False, allow_nan=False, indent=2) + "\n"
        if args.output is None:
            sys.stdout.write(payload)
        else:
            args.output.write_text(payload, encoding="utf-8")
        if args.curve_output is not None:
            with args.curve_output.open("w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=("x", "model", "ideal", "random"))
                writer.writeheader()
                writer.writerows(result.curve)
        return 0
    except (OSError, ValueError, csv.Error) as error:
        print(f"coverage-lift: error: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
